BIENVENIDO A TRANSparencia CONECTADA

¡Felicidades! Has descargado el prototipo de la plataforma de transparencia más accesible de Oaxaca.

📌 CÓMO USAR ESTA CARPETA:

1. Abre la carpeta "TransparenciaConectada_Prototipo"
2. Sube TODOS los archivos a: https://www.netlify.com (arrastra la carpeta completa)
3. ¡Tu sitio estará vivo en segundos! URL tipo: https://tunombre.netlify.app

🔧 PERSONALIZACIÓN:
- Edita los archivos .csv con Excel o Google Sheets
- Cambia el enlace del mapa en "Mapa_GoogleMyMaps_Enlace.html"
- Actualiza el formulario en "Formulario_Reporte.url"
- Usa Canva para cambiar el logo

💡 ¿QUÉ HACER AHORA?
- Envía el link a 5 aliados: OSC, periodistas, maestros, líderes
- Publica en Facebook: “Acabamos de lanzar Transparencia Conectada”
- Invita a estudiantes de la UABJO a hacer su servicio social

✨ NO NECESITAS PROGRAMAR. SOLO NECESITAS VALOR.

#TransparenciaConectada #OaxacaQueMira #TuDineroTuVoz

Contacto: fannygabo2627@gmail.com